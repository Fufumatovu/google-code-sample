#pragma once

#include <string>
#include <vector>

std::string trim(std::string s);

std::vector<std::string> splitlines(std::string output);

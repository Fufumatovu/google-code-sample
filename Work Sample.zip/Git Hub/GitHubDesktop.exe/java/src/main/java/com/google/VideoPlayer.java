package com.google;

import java.util.ArrayList;
//import java.util.Collections;
import java.util.List;
import java.util.Random;

public class VideoPlayer {

  private final VideoLibrary videoLibrary;
  private List<Video> Videos;

  /** Monitor's if a video is playing */
  private boolean videoPlaying;
  /** Monitor's if a video is paused */
  private boolean videoPaused;

  /** Store's the Title of the video thats playing */
  private String currentVideoPlaying;


  public VideoPlayer() {
    this.videoLibrary = new VideoLibrary();
    this.videoPlaying = false;
    this.videoPaused = false;
    this.Videos = new ArrayList<>(videoLibrary.getVideos());
    this.currentVideoPlaying = "";
  }

  /** Show the total number of videos available */
  public void numberOfVideos() {
    System.out.printf("%s videos in the library%n", videoLibrary.getVideos().size());
  }

  /** Show all of the videos */
  public void showAllVideos() {

    //Collections.sort(this.Videos);
    for (Video video : this.Videos) {
      String tags = video.getTags().toString();
      String newTags = tags.replace(",", "");
      System.out.println(video.getTitle() + " (" + video.getVideoId() +  ") " + newTags);
    }
    
  
  }

  /** Play the video */
  public void playVideo(String videoId) {

    String videoTitle = "";

    /** Finds the corresponding videoID in the ArrayList */
    for (Video video : Videos) {
      String videoID = video.getVideoId();

      /** Stores the Title of the video */
      if (videoID.equals(videoId)) {
        videoTitle = video.getTitle();
      }

    }

    /** if the video does not exist */
    if (videoTitle.isEmpty()) {
      System.out.println("Cannot play video: Video does not exist");
    } else {

      /** if there is no video playing */
      if (this.videoPlaying == false) {
        System.out.println("Playing video: " + videoTitle);
        this.videoPlaying = true;
        this.currentVideoPlaying = videoTitle;

        /** if there is a video playing */
      } else if (this.videoPlaying == true) {
        stopVideo();
        System.out.println("Playing video: " + videoTitle);
        this.currentVideoPlaying = videoTitle;
        this.videoPlaying = true;
      }
    } 
    
  }

  /** Stops the video */
  public void stopVideo() {

    /** if there is a video playing, stop the video*/
    if (this.videoPlaying == true) {
      System.out.println("Stopping video: " + this.currentVideoPlaying);
      this.currentVideoPlaying = "";
      this.videoPlaying = false;
      this.videoPaused = false;

    /** if there is no video playing, display error */
    } else if (this.videoPlaying == false) {
      System.out.println("Cannot stop video: No video is currently playing");
    }
    
  }

  /** Plays a random video */
  public void playRandomVideo() {
    
    /** Picks a random video */
    Random randNumber = new Random();
    Video video = Videos.get(randNumber.nextInt(Videos.size()));

    /** If there is no video playing, play the random video */
    if (this.videoPlaying == false) {
      System.out.println("Playing video: " + video.getTitle());
      this.currentVideoPlaying = video.getTitle();
      this.videoPlaying = true;

    /** If there is a video playing, stop the video and play the random video */
    } else if (this.videoPlaying == true) {
      stopVideo();
      System.out.println("Playing video: " + video.getTitle());
      this.videoPlaying = true;
      this.currentVideoPlaying = video.getTitle();
    }
    
  }

  /** Pause a video currently playing */
  public void pauseVideo() {

    /** if the video is paused, display an error message */
    if (this.videoPaused == true) {
      System.out.println("Video already paused: " + this.currentVideoPlaying);
    } else {

      /** if there is a video playing, pause the video */
      if (this.videoPlaying == true) {
        System.out.println("Pausing video: " + this.currentVideoPlaying);
        this.videoPaused = true;

      /** if there is no video playing, display an error message */
      } else if (this.videoPlaying == false) {
        System.out.println("Cannot pause video: No video is currently playing");
      }
    }    
  }

  /** Continue playing a paused video */
  public void continueVideo() {

    /** if there is no video playing, display an error message*/
    if (this.videoPlaying == false) {
      System.out.println("Cannot continue video: No video is currently playing");

    /** if the video is not paused, display an error message*/
    } else if (this.videoPaused == false) {
      System.out.println("Cannot continue video: Video is not paused");

    /** if the video is paused, continue the video*/
    } else if (this.videoPaused == true) {
      System.out.println("Continuing video: " + this.currentVideoPlaying);
      this.videoPaused = false;
    }

  }

  /** Show the current video playing */
  public void showPlaying() {

    /** if there is no video playing, display an error message */
    if (this.videoPlaying == false) {
      System.out.println("No video is currently playing");
    } else {

      for (Video video : Videos) {

        /** Find the details of the video */
        if (video.getTitle().equals(currentVideoPlaying)) {
          String tags = video.getTags().toString();
          String newTags = tags.replace(",", "");
          String videoDetails = "Currently playing: " + video.getTitle() + " (" + video.getVideoId() +  ") " + newTags;
          
          /** if the video is paused, included the Paused status at the end */
          if (this.videoPaused == true) {
            System.out.println(videoDetails + " - PAUSED");
        
          /** if the video is not paused, diplay the message as normal */
          } else if (this.videoPaused == false) {
            System.out.println(videoDetails);
          }
        }

      }
    }
  }

  public void createPlaylist(String playlistName) {
    System.out.println("Successfully created new playlist: " + playlistName);
  }

  public void addVideoToPlaylist(String playlistName, String videoId) {
    System.out.println("addVideoToPlaylist needs implementation");
  }

  public void showAllPlaylists() {
    System.out.println("showAllPlaylists needs implementation");
  }

  public void showPlaylist(String playlistName) {
    System.out.println("showPlaylist needs implementation");
  }

  public void removeFromPlaylist(String playlistName, String videoId) {
    System.out.println("removeFromPlaylist needs implementation");
  }

  public void clearPlaylist(String playlistName) {
    System.out.println("clearPlaylist needs implementation");
  }

  public void deletePlaylist(String playlistName) {
    System.out.println("deletePlaylist needs implementation");
  }

  public void searchVideos(String searchTerm) {
    System.out.println("searchVideos needs implementation");
  }

  public void searchVideosWithTag(String videoTag) {
    System.out.println("searchVideosWithTag needs implementation");
  }

  public void flagVideo(String videoId) {
    System.out.println("flagVideo needs implementation");
  }

  public void flagVideo(String videoId, String reason) {
    System.out.println("flagVideo needs implementation");
  }

  public void allowVideo(String videoId) {
    System.out.println("allowVideo needs implementation");
  }
}